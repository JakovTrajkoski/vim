This is a mirror of http://www.vim.org/scripts/script.php?script_id=1492

This is a light theme I use for coding.
Background is very light grey, special things are green or blue, this is for gui only and uses italic for some things (which I find very nice as its makes gvim look less console-like).

Screenshot: http://leetless.de/vim.html
